package Enum;

/**
 * Created by Baskakov on 10.08.2014.
 */
public enum  Locators {

}
